"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var AppConfig = (function () {
    function AppConfig() {
        this.apiUrl = 'http://localhost:4000';
    }
    return AppConfig;
}());
exports.AppConfig = AppConfig;
;
//# sourceMappingURL=app.config.js.map