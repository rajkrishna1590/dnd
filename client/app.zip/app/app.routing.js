"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var router_1 = require("@angular/router");
var index_1 = require("./home/index");
var index_2 = require("./login/index");
var index_3 = require("./upload/index");
var index_4 = require("./read/index");
var index_5 = require("./register/index");
var index_6 = require("./_guards/index");
var appRoutes = [
    { path: '', component: index_1.HomeComponent, canActivate: [index_6.AuthGuard] },
    { path: 'upload', component: index_3.UploadComponent, canActivate: [index_6.AuthGuard] },
    { path: 'read', component: index_4.ReadComponent, canActivate: [index_6.AuthGuard] },
    { path: 'login', component: index_2.LoginComponent },
    { path: 'register', component: index_5.RegisterComponent },
    // otherwise redirect to home
    { path: '**', redirectTo: '' }
];
exports.routing = router_1.RouterModule.forRoot(appRoutes);
//# sourceMappingURL=app.routing.js.map